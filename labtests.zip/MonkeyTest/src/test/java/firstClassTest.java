import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Arrays;

import static org.testng.Assert.*;

public class firstClassTest extends DataProviderTest {

    @Test(groups = "firstFigure")
    public void testFst() {
        double x = -2;
        double y = 1;
        boolean fst = firstClass.fst(x,y);
        Assert.assertEquals(fst, true);
    }

    @Test(groups = "firstFigure")
    public void testSec() {
        double x = 0;
        double y = 1;
        boolean sec = firstClass.sec(x,y);
        Assert.assertEquals(sec, true);
    }

    @Test(groups = "secondFigure")
    public void testThr() {
        double x = 3;
        double y = 0;
        boolean thr = firstClass.thr(x,y);
        Assert.assertEquals(thr, true);
    }

    @Test(groups = "secondFigure")
    public void testFoh() {
        double x = 4;
        double y = -1;
        boolean foh = firstClass.foh(x,y);
        Assert.assertEquals(foh, true);
    }

    @Test(groups = "twoFigures")
    public void testAll_Square() {
        double x = 0;
        double y = 1;
        int all = firstClass.All_Square(x,y);
        Assert.assertEquals(all, 1);
    }

    @Test(dataProvider = "Data")
    public void All_Squares() throws IOException {
        double[][] data = arraysData();
        for (int i = 0; i < data.length; i++) {
            double[] dataOne = data[i];
            double expected = dataOne[2];
            int result = firstClass.All_Square(dataOne[0], dataOne[1]);
            Assert.assertEquals(result, expected);
        }
    }
}
