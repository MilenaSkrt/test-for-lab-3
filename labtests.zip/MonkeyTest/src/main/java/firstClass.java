import java.util.Scanner;
import static java.lang.Math.*;

public class firstClass {
    public static boolean fst(double x, double y) {
        if (4 >= pow(x+1,2) + pow(y-1,2) & x <= -1) {
            return true;
        }
        return false;
    }
    public static boolean sec(double x, double y) {
        if (y <= -3/2 * x  + 3.5 & y >= -2 * x  -1  &
                x >= -1 & y >= 3*x -1) {
            return true;
        }
        return false;
    }
    public static boolean thr(double x, double y) {
        if (y >= abs(x-3) & y <= 1)  {
            return true;
        }
        return false;
    }
    public static boolean foh(double x, double y) {
        if (4 >= pow(x-4,2) + pow(y+1,2) & y <= x-3 & y >= x -7){
            return true;
        }
        return false;
    }
    public static int All_Square(double x, double y) {
        if (fst(x,y) || sec(x,y)) {
            System.out.println("Попадание в левую фигуру");
            return 1;
        } else if(thr(x,y) || foh(x,y)){
            System.out.println("Попадание в правую фигуру");
            return 2;
        } else {
            System.out.println("Не попала");
            return 0;
        }
    }
}